<?php

defined('BASEPATH') OR exit('No Direct Script Allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Mahasiswa extends REST_Controller{

  public function __construct(){
    parent::__construct();
  }

  public function fieldKosong(){
    $response['error']=1;
    $response['pesan']='Tidak boleh ada field yang kosong';
    $this->response($response);
  }

  public function tambah_post(){

    $nim = $this->post('nim');
    $nama = $this->post('nama');
    $alamat = $this->post('alamat');
    $jenkel = $this->post('jenkel');

    if(!$nim || !$nama || !$alamat || !$jenkel){
      $this->fieldKosong();
    }else{

      $tambah = $this->db->query("INSERT INTO mahasiswa VALUES ('$nim','$nama','$alamat','$jenkel')");

      if($tambah){
        $response['error']=0;
        $response['pesan']='Data berhasil ditambahkan';
        $this->response($response);
      }else{
        $response['error']=1;
        $response['pesan']='Data gagal ditambahkan';
        $this->response($response);
      }

    }

  }

  public function semua_get(){

    $semua = $this->db->query("SELECT * FROM mahasiswa ORDER BY nim DESC")->result();

    $response['error']=0;
    $response['data']=$semua;
    $this->response($response);

  }

  public function perbarui_put(){

    $nim = $this->put('nim');
    $nama = $this->put('nama');
    $alamat = $this->put('alamat');
    $jenkel = $this->put('jenkel');

    if(!$nim || !$nama || !$alamat || !$jenkel){
      $this->fieldKosong();
    }else{

      $perbarui = $this->db->query("UPDATE mahasiswa SET nama='$nama', alamat='$alamat', jenkel='$jenkel' WHERE nim='$nim'");

      if($perbarui){
        $response['error']=0;
        $response['pesan']='Data berhasil diperbarui';
        $this->response($response);
      }else{
        $response['error']=1;
        $response['pesan']='Data gagal diperbarui';
        $this->response($response);
      }

    }

  }

  public function hapus_get(){

    $nim = $this->get('nim');

    if(!$nim){
      $this->fieldKosong();
    }else{

      $hapus = $this->db->query("DELETE FROM mahasiswa WHERE nim='$nim'");

      if($hapus){
        $response['error']=0;
        $response['pesan']='Data berhasil dihapus';
        $this->response($response);
      }else{
        $response['error']=1;
        $response['pesan']='Data gagal dihapus';
        $this->response($response);
      }

    }

  }


}

?>
